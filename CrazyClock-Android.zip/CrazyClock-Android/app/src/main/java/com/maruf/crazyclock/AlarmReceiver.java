package com.maruf.crazyclock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        c.startForegroundService(new Intent(c, AlarmService.class).putExtra("id", i.getLongExtra("id", 0)));
    }
}
