# CRAZY CLOCK – Android app (real alarms)

এই প্রজেক্টে ওয়েব-অ্যাপটাই (assets/index.html) একটি আসল অ্যান্ড্রয়েড অ্যাপের ভেতরে বসানো। অ্যালার্ম AlarmManager দিয়ে সেট হয়,
তাই স্ক্রিন লক বা অ্যাপ বন্ধ থাকলেও বাজে, লক স্ক্রিনের ওপর চ্যালেঞ্জ দেখায়, আসল ফ্লাশ লাইট জ্বলে, রিস্টার্টের পরও আবার সেট হয়।

## APK বানানোর ২টি উপায়
**১) Android Studio (কম্পিউটারে)**
1. Android Studio (Hedgehog/Iguana বা নতুন) ইনস্টল করুন।
2. File > Open > এই `CrazyClock-Android` ফোল্ডার বেছে নিন, Gradle Sync শেষ হতে দিন।
3. Build > Build Bundle(s)/APK(s) > Build APK(s)। `app/build/outputs/apk/debug/app-debug.apk` ফোনে পাঠিয়ে ইনস্টল করুন
   (Settings-এ "Install unknown apps" চালু করতে হবে)।

**২) GitHub Actions (ইনস্টল ছাড়া)**
1. GitHub-এ নতুন repo বানিয়ে এই ফোল্ডারের সব ফাইল (`.github` সহ) আপলোড করুন।
2. Actions ট্যাবে "Build APK" চলার পর শেষে Artifacts থেকে `CrazyClock-apk` নামিয়ে নিন।

## প্রথমবার খুলে যা দিতে হবে
- Notifications: Allow
- Alarms & reminders (exact alarm): Allow
- Full-screen notifications: Allow
- Camera: Allow (ছবির চ্যালেঞ্জের জন্য)
- Settings > Apps > CRAZY CLOCK > Battery: Unrestricted (শাওমি/ওপ্পো/ভিভো/স্যামসাংয়ে "Autostart"/"Lock in recents"ও চালু রাখুন)

## মনে রাখবেন
- ফোন সম্পূর্ণ বন্ধ (Power off) থাকলে কোনো অ্যাপই বাজাতে পারে না।
- অ্যালার্ম বদলালে অ্যাপ নিজে থেকেই পরের ১৪ দিনের সময় সেট করে রাখে; অ্যাপ অনেকদিন না খুললে আবার একবার খুলে নিন।
- বাজার সময় মিডিয়া ভলিউম নিজে থেকে সর্বোচ্চ করা হয়।
