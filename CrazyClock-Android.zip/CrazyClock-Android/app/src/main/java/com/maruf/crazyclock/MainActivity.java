package com.maruf.crazyclock;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Hosts the CRAZY CLOCK web UI (assets/index.html). Alarms are scheduled natively so they ring when the screen is locked. */
public class MainActivity extends Activity {
    private WebView wv;
    private boolean ringing, loaded, askedExact, askedFsi;
    private long pending;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.addJavascriptInterface(new Bridge(), "Native");
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> r.grant(r.getResources()));
            }
        });
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) {
                loaded = true;
                if (pending != 0) { ring(pending); pending = 0; }
            }
        });
        wv.loadUrl("file:///android_asset/index.html");
        if (!handle(getIntent())) {
            String[] p = Build.VERSION.SDK_INT >= 33
                    ? new String[]{Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS}
                    : new String[]{Manifest.permission.CAMERA};
            requestPermissions(p, 1);
        }
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handle(i); }

    /** Returns true when this launch came from a ringing alarm. */
    private boolean handle(Intent i) {
        long id = i == null ? 0 : i.getLongExtra("ringId", 0);
        if (id == 0) return false;
        i.removeExtra("ringId");
        ringing = true;
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
        } catch (Exception e) { }
        if (loaded) ring(id); else pending = id;
        return true;
    }

    private void ring(long id) { wv.evaluateJavascript("window.nativeRing&&nativeRing(" + id + ")", null); }

    private void svc(String action) {
        try { startService(new Intent(this, AlarmService.class).setAction(action)); } catch (Exception e) { }
    }

    @Override protected void onResume() {
        super.onResume();
        if (ringing) { svc("take"); return; }
        if (Build.VERSION.SDK_INT >= 31 && !askedExact && !((AlarmManager) getSystemService(ALARM_SERVICE)).canScheduleExactAlarms()) {
            askedExact = true;
            startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
        } else if (Build.VERSION.SDK_INT >= 34 && !askedFsi && !((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).canUseFullScreenIntent()) {
            askedFsi = true;
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName())));
        }
    }

    @Override protected void onStop() { super.onStop(); if (ringing) svc("fall"); }

    @Override public void onBackPressed() { if (!ringing) super.onBackPressed(); }

    private class Bridge {
        @JavascriptInterface public void sync(String json) { Sched.save(MainActivity.this, json); }
        @JavascriptInterface public void takeOver() { svc("take"); }
        @JavascriptInterface public void ended() {
            ringing = false;
            svc("stop");
            runOnUiThread(() -> {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(false); setTurnScreenOn(false); }
            });
        }
    }
}
