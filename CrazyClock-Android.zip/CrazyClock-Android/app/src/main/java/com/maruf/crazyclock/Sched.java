package com.maruf.crazyclock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

/** Keeps the list of upcoming alarm times (sent by the web UI) and schedules them with AlarmManager. */
final class Sched {
    private static final String PREF = "crazy", KEY = "sched";

    static void save(Context c, String json) {
        each(c, false);
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, json).apply();
        each(c, true);
    }

    static void restore(Context c) { each(c, true); }

    private static PendingIntent fire(Context c, long id, long at) {
        Intent i = new Intent(c, AlarmReceiver.class).putExtra("id", id);
        int code = (int) ((id * 31 + at / 1000) & 0x7fffffff);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void each(Context c, boolean set) {
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]"));
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long now = System.currentTimeMillis();
            for (int k = 0; k < a.length(); k++) {
                JSONObject o = a.getJSONObject(k);
                long id = o.getLong("id"), at = o.getLong("at");
                PendingIntent p = fire(c, id, at);
                if (!set) { am.cancel(p); continue; }
                if (at <= now) continue;
                PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
                try { am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), p); } catch (SecurityException e) { }
            }
        } catch (Exception e) { }
    }
}
