package com.maruf.crazyclock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Runs while an alarm is ringing: wake lock, flashlight, full-screen notification, and a fallback ringtone. */
public class AlarmService extends Service {
    static final String CH = "alarm";
    private MediaPlayer mp;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable fallback = this::startFallback;
    private String torchId;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        String a = i == null ? null : i.getAction();
        if ("stop".equals(a)) { cleanup(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        if ("take".equals(a)) { h.removeCallbacks(fallback); stopFallback(); if (wl == null) stopSelf(); return START_NOT_STICKY; }
        if ("fall".equals(a)) { if (wl == null) stopSelf(); else startFallback(); return START_NOT_STICKY; }

        long id = i == null ? 0 : i.getLongExtra("id", 0);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Alarms", NotificationManager.IMPORTANCE_HIGH));
        Intent ai = new Intent(this, MainActivity.class).putExtra("ringId", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, ai, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("CRAZY CLOCK")
                .setContentText("Wake up! Tap to open")
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);

        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "crazyclock:ring");
            wl.acquire(10 * 60 * 1000L);
        }
        torch(true);
        try { startActivity(ai); } catch (Exception e) { }
        h.removeCallbacks(fallback);
        h.postDelayed(fallback, 8000);   // if the screen UI does not take over in 8 s, ring with the system alarm tone
        return START_NOT_STICKY;
    }

    private void torch(boolean on) {
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            if (on && torchId == null) {
                for (String id : cm.getCameraIdList()) {
                    CameraCharacteristics c = cm.getCameraCharacteristics(id);
                    Boolean f = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer l = c.get(CameraCharacteristics.LENS_FACING);
                    if (f != null && f && l != null && l == CameraCharacteristics.LENS_FACING_BACK) { torchId = id; break; }
                }
            }
            if (torchId != null) cm.setTorchMode(torchId, on);
            if (!on) torchId = null;
        } catch (Exception e) { }
    }

    private void startFallback() {
        if (mp != null) return;
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            mp.setLooping(true);
            mp.prepare();
            mp.start();
        } catch (Exception e) { mp = null; }
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 600, 400}, 0));
    }

    private void stopFallback() {
        if (mp != null) { try { mp.stop(); mp.release(); } catch (Exception e) { } mp = null; }
        Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (v != null) v.cancel();
    }

    private void cleanup() {
        h.removeCallbacks(fallback);
        stopFallback();
        torch(false);
        if (wl != null && wl.isHeld()) wl.release();
        wl = null;
    }

    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
}
